<?php include('header.php'); ?>

<main>
    <h2>Page d'accueil</h2>
    <p>Bienvenue sur la page d'accueil de mon site web !</p>
</main>

<?php include('footer.php'); ?>
