    <footer>
        <p>&copy; <?php echo date("Y"); ?> Mon Site. Tous droits réservés.</p>
    </footer>
</body>
</html>
